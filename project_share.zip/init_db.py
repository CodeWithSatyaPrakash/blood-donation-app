import sqlite3
from werkzeug.security import generate_password_hash

def init_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Create users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            blood_group TEXT NOT NULL,
            last_donation_date TEXT
        )
    ''')

    # Create camps table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS camps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            camp_name TEXT NOT NULL,
            location TEXT NOT NULL,
            date TEXT NOT NULL
        )
    ''')

    # Seed users
    users = [
        ('John', 'Doe', 'john@example.com', generate_password_hash('password123'), 'O+', '2023-10-15'),
        ('Jane', 'Smith', 'jane@example.com', generate_password_hash('password123'), 'A-', '2024-01-20'),
        ('Alice', 'Johnson', 'alice@example.com', generate_password_hash('password123'), 'B+', '2023-11-05')
    ]
    cursor.executemany('INSERT OR IGNORE INTO users (first_name, last_name, email, password_hash, blood_group, last_donation_date) VALUES (?, ?, ?, ?, ?, ?)', users)

    # Seed camps
    camps = [
        ('City General Hospital Camp', '123 Main St, Downtown', '2024-05-15'),
        ('Community Center Drive', '456 Oak St, Suburbs', '2024-06-10'),
        ('University Blood Drive', 'Student Union Building', '2024-04-22')
    ]
    cursor.executemany('INSERT OR IGNORE INTO camps (camp_name, location, date) VALUES (?, ?, ?)', camps)

    conn.commit()
    conn.close()
    print("Database initialized and seeded successfully.")

if __name__ == '__main__':
    init_db()
